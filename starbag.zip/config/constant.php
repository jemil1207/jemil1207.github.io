<?php
define('SITE_URL', 'https://starbagcentre.com');
define('SITE_NAME', 'Star Bag Centre');

/*** Validation Errors */
define('NAME_REQUIRED', 'Please enter your name');
define('EMAIL_REQUIRED', 'Please enter your email');
define('EMAIL_INVALID', 'Please enter a valid email');
define('PHONE_REQUIRED', 'Please enter your mobile number');
define('PHONE_INVALID', 'Please enter a valid mobile number');
define('ADDRESS_REQUIRED', 'Please enter your address');

/** MAIL CONFIG */
define('MAIL_HOST', 'r1.dnspark.in');
define('MAIL_USERNAME', 'info@starbagcentre.com');
define('MAIL_PASSWORD', 'starbag!@#$%');
define('MAIL_FROM', 'no-reply@starbagcentre.com');
define('ADMIN_EMAIL', 'info@starbagcentre.com');

